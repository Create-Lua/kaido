#!/usr/bin/env python3

def main():
    print("Kaido CLI running")

if __name__ == "__main__":
    main()